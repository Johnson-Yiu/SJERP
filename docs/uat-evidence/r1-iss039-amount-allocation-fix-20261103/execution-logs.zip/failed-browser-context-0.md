# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: iss039-amount-allocation-real.spec.js >> amount-only and deliberate legacy conversion, real Chrome 1440px
- Location: browser-tests\iss039-amount-allocation-real.spec.js:19:3

# Error details

```
Test timeout of 120000ms exceeded.
```

```
Error: locator.selectOption: Test timeout of 120000ms exceeded.
Call log:
  - waiting for getByRole('dialog', { name: /采购成本分配/ }).locator('.cost-item').first().getByLabel('成本归属', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=f4e3]:
  - complementary [ref=f4e4]:
    - generic [ref=f4e5]:
      - generic [ref=f4e6]: S
      - generic [ref=f4e7]:
        - strong [ref=f4e8]: 森爵照明管理系统
        - text: 客户 · 销售 · 产品
    - navigation [ref=f4e9]:
      - generic [ref=f4e10]: 经营
      - link "经营概览" [ref=f4e11] [cursor=pointer]:
        - /url: /
      - link "报表中心" [ref=f4e18] [cursor=pointer]:
        - /url: /reports
      - link "历史订单分析" [ref=f4e25] [cursor=pointer]:
        - /url: /historical-orders
      - generic [ref=f4e31]: 客户
      - link "客户管理" [ref=f4e32] [cursor=pointer]:
        - /url: /customers
      - link "联系人" [ref=f4e39] [cursor=pointer]:
        - /url: /contacts
      - link "跟进记录" [ref=f4e45] [cursor=pointer]:
        - /url: /follow-ups
      - generic [ref=f4e49]: 销售
      - link "报价管理" [ref=f4e50] [cursor=pointer]:
        - /url: /quotes
      - link "订单管理" [ref=f4e55] [cursor=pointer]:
        - /url: /orders
      - generic [ref=f4e61]: 采购与库存
      - link "供应商管理" [ref=f4e62] [cursor=pointer]:
        - /url: /suppliers
      - link "采购管理" [ref=f4e69] [cursor=pointer]:
        - /url: /purchase-orders
      - link "库存" [ref=f4e75] [cursor=pointer]:
        - /url: /inventory
      - link "库存流水" [ref=f4e80] [cursor=pointer]:
        - /url: /inventory-movements
      - generic [ref=f4e85]: 产品资料
      - link "产品管理" [ref=f4e86] [cursor=pointer]:
        - /url: /products
      - link "SKU 管理" [ref=f4e92] [cursor=pointer]:
        - /url: /skus
      - link "产品分类" [ref=f4e104] [cursor=pointer]:
        - /url: /categories
      - link "产品参数" [ref=f4e110] [cursor=pointer]:
        - /url: /product-parameters
      - link "包装管理" [ref=f4e113] [cursor=pointer]:
        - /url: /sku-packaging
      - link "交易单位" [ref=f4e119] [cursor=pointer]:
        - /url: /sku-trade-units
      - link "产品证书" [ref=f4e131] [cursor=pointer]:
        - /url: /product-certificates
      - link "HS 编码维护" [ref=f4e136] [cursor=pointer]:
        - /url: /hs-codes
      - generic [ref=f4e139]: 财务与工具
      - link "财务概览" [ref=f4e140] [cursor=pointer]:
        - /url: /finance
      - link "应收计划" [ref=f4e146] [cursor=pointer]:
        - /url: /receivables
      - link "应付计划" [ref=f4e152] [cursor=pointer]:
        - /url: /payables
      - link "财务流水" [ref=f4e158] [cursor=pointer]:
        - /url: /transactions
      - link "人民币资金" [ref=f4e164] [cursor=pointer]:
        - /url: /rmb-cash-events
      - link "数据导入" [ref=f4e170] [cursor=pointer]:
        - /url: /import
      - generic [ref=f4e175]: 组织与系统
      - link "组织与权限" [ref=f4e176] [cursor=pointer]:
        - /url: /organization
    - generic [ref=f4e181]:
      - generic [ref=f4e182]: J
      - generic [ref=f4e184]:
        - strong [ref=f4e185]: 开发身份：Johnson
        - generic [ref=f4e186]: 超级管理员 · 全部功能与数据权限
  - main [ref=f4e187]:
    - generic [ref=f4e188]:
      - generic [ref=f4e189]:
        - text: Procurement desk
        - heading "采购管理" [level=1] [ref=f4e190]
      - generic [ref=f4e191]:
        - generic [ref=f4e192]: 11月3日周二
        - generic "Johnson" [ref=f4e193]: J
    - generic [ref=f4e195]:
      - dialog [ref=f4e197]:
        - generic [ref=f4e198]:
          - generic [ref=f4e199]:
            - text: 采购管理 / 成本核算
            - heading "采购成本分配 C039-62a30bb3-new" [level=3] [ref=f4e200]:
              - text: 采购成本分配
              - generic [ref=f4e201]: C039-62a30bb3-new
            - paragraph [ref=f4e202]: 将商品成本分配给订单与库存，再统一分摊公共费用。
          - button "关闭成本分配" [ref=f4e203] [cursor=pointer]
        - generic [ref=f4e207]:
          - article [ref=f4e208]:
            - generic [ref=f4e209]: 采购商品金额
            - strong [ref=f4e210]: 11,000.00 CNY
          - article [ref=f4e211]:
            - generic [ref=f4e212]: 公共附加费用
            - strong [ref=f4e213]: 0.00 CNY
          - article [ref=f4e214]:
            - generic [ref=f4e215]: 本次核算总成本
            - strong [ref=f4e216]: 11,000.00 CNY
        - group [ref=f4e218]:
          - paragraph [ref=f4e219]: 采购成本默认归来源订单，无来源订单时归库存。保存调整后保留分配版本。
          - generic [ref=f4e222]:
            - generic [ref=f4e223]:
              - heading "明细成本归属" [level=4] [ref=f4e224]
              - paragraph [ref=f4e229]: 展开商品，填写每份归属的数量；未分配的余量自动归库存。
            - generic [ref=f4e230]: 2 项商品
          - group [ref=f4e231]:
            - generic "› C039-62a30bb3 合成商品 C039-62a30bb3 · 采购 10.00 件 × CNY 1,000.00 · 分配基数 10.00 件 剩余 0.00" [ref=f4e232] [cursor=pointer]:
              - text: ›
              - generic [ref=f4e233]:
                - generic [ref=f4e234]: C039-62a30bb3 合成商品
                - generic [ref=f4e235]: C039-62a30bb3 · 采购 10.00 件 × CNY 1,000.00 · 分配基数 10.00 件
              - generic [ref=f4e236]: 剩余 0.00
            - generic [ref=f4e237]:
              - generic [ref=f4e238]:
                - text: 成本归属
                - combobox "成本归属" [ref=f4e239]:
                  - option "销售订单"
                  - option "库存" [selected]
                  - option "样品"
                  - option "损耗"
                  - option "赠品"
                  - option "售后补发"
                  - option "研发试制"
                  - option "内部领用"
                  - option "展会推广"
                  - option "其他"
              - generic [ref=f4e240]:
                - text: 分配数量
                - spinbutton "分配数量" [ref=f4e241]: "10"
              - button "删除" [ref=f4e242] [cursor=pointer]
            - button "添加成本归属" [ref=f4e243] [cursor=pointer]
          - group [ref=f4e245]:
            - generic "› C039-62a30bb3 合成商品 C039-62a30bb3 · 采购 10.00 件 × CNY 100.00 · 分配基数 10.00 件 剩余 0.00" [ref=f4e246] [cursor=pointer]:
              - text: ›
              - generic [ref=f4e247]:
                - generic [ref=f4e248]: C039-62a30bb3 合成商品
                - generic [ref=f4e249]: C039-62a30bb3 · 采购 10.00 件 × CNY 100.00 · 分配基数 10.00 件
              - generic [ref=f4e250]: 剩余 0.00
            - generic [ref=f4e251]:
              - generic [ref=f4e252]:
                - text: 成本归属
                - combobox "成本归属" [ref=f4e253]:
                  - option "销售订单"
                  - option "库存" [selected]
                  - option "样品"
                  - option "损耗"
                  - option "赠品"
                  - option "售后补发"
                  - option "研发试制"
                  - option "内部领用"
                  - option "展会推广"
                  - option "其他"
              - generic [ref=f4e254]:
                - text: 分配数量
                - spinbutton "分配数量" [ref=f4e255]: "10"
              - button "删除" [ref=f4e256] [cursor=pointer]
            - button "添加成本归属" [ref=f4e257] [cursor=pointer]
          - generic [ref=f4e260]:
            - heading "公共附加费用" [level=4] [ref=f4e261]
            - paragraph [ref=f4e267]: 运费、关税等公共费用按采购金额比例分摊。
          - generic [ref=f4e268]: 暂无附加费用，可添加运费、关税或杂费。
          - paragraph [ref=f4e269]: 公共费用按采购金额比例分担，历史记录保留原算法。此处不生成付款或入库；已分摊的费用请勿再次作为订单费用录入。
          - button "添加附加费用" [ref=f4e270] [cursor=pointer]
        - generic [ref=f4e272]:
          - heading "当前成本归属" [level=4] [ref=f4e273]
          - table [ref=f4e275]:
            - rowgroup [ref=f4e276]:
              - row [ref=f4e277]:
                - columnheader "采购明细" [ref=f4e278]
                - columnheader "归属" [ref=f4e279]
                - columnheader "数量" [ref=f4e280]
                - columnheader "商品成本" [ref=f4e281]
                - columnheader "附加费用" [ref=f4e282]
                - columnheader "合计" [ref=f4e283]
            - rowgroup [ref=f4e284]:
              - row [ref=f4e285]:
                - cell "C039-62a30bb3 合成商品" [ref=f4e286]
                - cell "库存" [ref=f4e287]
                - cell "10" [ref=f4e288]
                - cell "10,000.00" [ref=f4e289]
                - cell "0.00" [ref=f4e290]
                - cell "10,000.00" [ref=f4e291]
              - row [ref=f4e292]:
                - cell "C039-62a30bb3 合成商品" [ref=f4e293]
                - cell "库存" [ref=f4e294]
                - cell "10" [ref=f4e295]
                - cell "1,000.00" [ref=f4e296]
                - cell "0.00" [ref=f4e297]
                - cell "1,000.00" [ref=f4e298]
          - paragraph [ref=f4e299]: 商品成本 11,000.00 ＋ 附加费用 0.00 ＝ CNY 11,000.00
          - paragraph [ref=f4e300]: 草稿及取消采购不计入订单预估毛利；库存成本表示成本归属，不代表已到货库存。
        - generic [ref=f4e301]:
          - generic [ref=f4e302]: 修改数量、归属或费用，自动更新预览
          - generic [ref=f4e303]:
            - button "取消" [ref=f4e304] [cursor=pointer]
            - button "保存成本分配" [ref=f4e305] [cursor=pointer]
      - generic [ref=f4e308]:
        - paragraph [ref=f4e309]: 管理采购下单、到货与供应商应付。
        - generic [ref=f4e310]:
          - button "刷新" [ref=f4e311] [cursor=pointer]
          - button "新建采购单" [ref=f4e317] [cursor=pointer]
      - region "页面小计" [ref=f4e320]:
        - article [ref=f4e321]:
          - generic [ref=f4e322]: 执行中
          - strong [ref=f4e323]: "3"
          - generic [ref=f4e324]: 已下单 / 部分到货
        - article [ref=f4e328]:
          - generic [ref=f4e329]: 待到货
          - strong [ref=f4e330]: "3"
          - generic [ref=f4e331]: 尚未全部到货
        - article [ref=f4e335]:
          - generic [ref=f4e336]: 待付款
          - strong [ref=f4e337]: "2"
          - generic [ref=f4e338]: 仍有应付余额
        - article [ref=f4e342]:
          - generic [ref=f4e343]: 已完成
          - strong [ref=f4e344]: "0"
          - generic [ref=f4e345]: 已完成采购
      - generic "采购单筛选" [ref=f4e349]:
        - generic [ref=f4e350]:
          - generic [ref=f4e351]: 搜索
          - searchbox "搜索采购单号、供应商、来源订单" [ref=f4e352]
        - generic [ref=f4e353]:
          - generic [ref=f4e354]: 状态
          - combobox "按状态筛选" [ref=f4e355]:
            - option "全部状态" [selected]
            - option "草稿"
            - option "已下单"
            - option "部分到货"
            - option "已完成"
            - option "已取消"
        - generic [ref=f4e356]:
          - checkbox "仅看待到货" [ref=f4e357]
          - text: 仅看待到货
        - button "重置" [disabled] [ref=f4e358] [cursor=pointer]
      - table [ref=f4e361]:
        - rowgroup [ref=f4e362]:
          - row [ref=f4e363]:
            - columnheader "采购单号" [ref=f4e364]
            - columnheader "供应商" [ref=f4e365]
            - columnheader "来源订单" [ref=f4e366]
            - columnheader "下单日期" [ref=f4e367]
            - columnheader "预计到货" [ref=f4e368]
            - columnheader "状态" [ref=f4e369]
            - columnheader "采购金额" [ref=f4e370]
            - columnheader "已付 / 未付" [ref=f4e371]
            - columnheader "操作" [ref=f4e372]
        - rowgroup [ref=f4e373]:
          - row [ref=f4e374] [cursor=pointer]:
            - cell "C039-62a30bb3-zero" [ref=f4e375]
            - cell "历史主体未记录" [ref=f4e376]
            - cell "—" [ref=f4e377]
            - cell "2026-11-03" [ref=f4e378]
            - cell "—" [ref=f4e379]
            - cell "已下单" [ref=f4e381]
            - cell "CNY 0.00" [ref=f4e383]
            - cell "0.00 / 0.00" [ref=f4e384]
            - cell [ref=f4e385]:
              - button "查看采购单 C039-62a30bb3-zero" [ref=f4e386]
          - row [ref=f4e390] [cursor=pointer]:
            - cell "C039-62a30bb3-legacy" [ref=f4e391]
            - cell "历史主体未记录" [ref=f4e392]
            - cell "—" [ref=f4e393]
            - cell "2026-11-03" [ref=f4e394]
            - cell "—" [ref=f4e395]
            - cell "已下单" [ref=f4e397]
            - cell "CNY 11,000.00" [ref=f4e399]
            - cell "0.00 / 11,000.00" [ref=f4e400]
            - cell [ref=f4e401]:
              - button "查看采购单 C039-62a30bb3-legacy" [ref=f4e402]
          - row [ref=f4e406] [cursor=pointer]:
            - cell "C039-62a30bb3-new" [ref=f4e407]
            - cell "历史主体未记录" [ref=f4e408]
            - cell "—" [ref=f4e409]
            - cell "2026-11-03" [ref=f4e410]
            - cell "—" [ref=f4e411]
            - cell "已下单" [ref=f4e413]
            - cell "CNY 11,000.00" [ref=f4e415]
            - cell "0.00 / 11,000.00" [ref=f4e416]
            - cell [ref=f4e417]:
              - button "查看采购单 C039-62a30bb3-new" [ref=f4e418]
      - dialog "采购工作台" [ref=f4e423]:
        - generic [ref=f4e424]:
          - button "关闭采购详情" [ref=f4e425] [cursor=pointer]:
            - generic [ref=f4e429]: 关闭
          - generic [ref=f4e430]: 采购工作台
          - paragraph [ref=f4e431]: 历史主体未记录 · 下单日期 2026-11-03
          - heading "C039-62a30bb3-new 已下单" [level=2] [ref=f4e432]:
            - text: C039-62a30bb3-new
            - generic [ref=f4e433]: 已下单
          - paragraph [ref=f4e434]: 预计到货 —
          - button "取消采购单" [ref=f4e436] [cursor=pointer]
        - navigation "采购工作台页签" [ref=f4e437]:
          - button "概览" [pressed] [ref=f4e438] [cursor=pointer]
          - button "采购明细" [ref=f4e439] [cursor=pointer]
          - button "收货" [ref=f4e440] [cursor=pointer]
          - button "供应商应付" [ref=f4e441] [cursor=pointer]
          - button "关联销售订单" [ref=f4e442] [cursor=pointer]
        - main [ref=f4e443]:
          - article [ref=f4e444]:
            - heading "交易主体快照" [level=3] [ref=f4e445]
            - paragraph [ref=f4e446]: 历史主体未记录，以下不使用当前主档补造历史事实。
            - paragraph [ref=f4e447]: 当前主档参考：C039-62a30bb3 合成供应商
          - article [ref=f4e448]:
            - heading "采购摘要" [level=3] [ref=f4e449]
            - generic [ref=f4e450]:
              - generic [ref=f4e451]:
                - generic [ref=f4e452]: 采购金额
                - strong [ref=f4e453]: CNY 11,000.00
              - generic [ref=f4e454]:
                - generic [ref=f4e455]: 商品项数
                - strong [ref=f4e456]: "2"
              - generic [ref=f4e457]:
                - generic [ref=f4e458]: 已付金额
                - strong [ref=f4e459]: CNY 0.00
              - generic [ref=f4e460]:
                - generic [ref=f4e461]: 未付金额
                - strong [ref=f4e462]: CNY 11,000.00
          - article [ref=f4e463]:
            - heading "当前待办" [level=3] [ref=f4e464]
            - generic [ref=f4e465]:
              - generic [ref=f4e466]:
                - text: 待到货
                - paragraph [ref=f4e467]: 还有 2 条明细未全部到货。
              - button "查看收货" [ref=f4e468] [cursor=pointer]
            - generic [ref=f4e469]:
              - generic [ref=f4e470]:
                - text: 待付款
                - paragraph [ref=f4e471]: 待付 CNY 11000.00
              - button "查看 / 登记付款" [ref=f4e472] [cursor=pointer]
          - generic [ref=f4e473]:
            - article [ref=f4e474]:
              - heading "到货进度" [level=3] [ref=f4e475]
              - generic [ref=f4e476]:
                - term [ref=f4e477]: 采购数量
                - definition [ref=f4e478]: 20 件
                - term [ref=f4e479]: 已到货
                - definition [ref=f4e480]: "0"
                - term [ref=f4e481]: 待到货
                - definition [ref=f4e482]: "20"
                - term [ref=f4e483]: 完成比例
                - definition [ref=f4e484]: 0%
            - article [ref=f4e485]:
              - heading "付款进度" [level=3] [ref=f4e486]
              - generic [ref=f4e487]:
                - term [ref=f4e488]: 应付 / 合同金额
                - definition [ref=f4e489]: CNY 11,000.00
                - term [ref=f4e490]: 已付
                - definition [ref=f4e491]: "0.00"
                - term [ref=f4e492]: 未付
                - definition [ref=f4e493]: 11,000.00
                - term [ref=f4e494]: 付款百分比
                - definition [ref=f4e495]: 0%
              - button "登记付款" [ref=f4e496] [cursor=pointer]
            - article [ref=f4e497]:
              - heading "采购成本分配" [level=3] [ref=f4e498]
              - paragraph [ref=f4e499]: 将采购成本和公共费用分配到关联销售订单。
              - button "分配采购成本 / 公共费用" [active] [ref=f4e500] [cursor=pointer]
          - generic [ref=f4e501]:
            - generic [ref=f4e502]:
              - generic [ref=f4e503]:
                - heading "合同金额调整" [level=4] [ref=f4e504]
                - paragraph [ref=f4e505]: 已确认调整会改变当前合同总额；调减只会减少未结清计划，不会自动退款。
              - strong [ref=f4e506]: CNY 11,000.00
            - generic [ref=f4e507]:
              - generic [ref=f4e508]: 基础金额 CNY 11,000.00
              - generic [ref=f4e509]: 已确认调整 CNY 0.00
            - generic [ref=f4e510]:
              - spinbutton "调整金额（正/负）" [ref=f4e511]
              - textbox [ref=f4e512]
              - textbox "调整说明" [ref=f4e513]
              - button "新增调整" [ref=f4e514] [cursor=pointer]
            - paragraph [ref=f4e515]: 暂无金额调整记录。
```

# Test source

```ts
  2   | import { spawnSync } from 'node:child_process'
  3   | import fs from 'node:fs'
  4   | import path from 'node:path'
  5   | 
  6   | test.use({ channel: 'chrome' })
  7   | const evidence = path.resolve(process.env.ISS039_EVIDENCE_ROOT || (process.env.ISOLATED_PLAYWRIGHT_EVIDENCE_ROOT ? path.join(process.env.ISOLATED_PLAYWRIGHT_EVIDENCE_ROOT, 'browser', 'iss039-amount-allocation') : '../docs/uat-evidence/r1-iss039-amount-allocation-fix-20261103/browser'))
  8   | const inspector = path.resolve('../docs/uat-evidence/r1-iss039-amount-allocation-fix-20261103/fixture.py')
  9   | fs.mkdirSync(evidence, { recursive: true })
  10  | 
  11  | function database(action) {
  12  |   if (!process.env.ISOLATED_TEST_PYTHON || !process.env.ISOLATED_TEST_RUN_ID) throw new Error('Use the verified isolated browser runner.')
  13  |   const result = spawnSync(process.env.ISOLATED_TEST_PYTHON, [inspector, action], { cwd: path.resolve('../backend'), env: process.env, encoding: 'utf8' })
  14  |   expect(result.status, result.stderr).toBe(0)
  15  |   return JSON.parse(result.stdout)
  16  | }
  17  | 
  18  | for (const width of [1440, 390]) {
  19  |   test(`amount-only and deliberate legacy conversion, real Chrome ${width}px`, async ({ page }) => {
  20  |     test.setTimeout(120000)
  21  |     const http = []
  22  |     page.on('response', async response => {
  23  |       const request = response.request()
  24  |       if (response.url().includes('/cost-allocation')) {
  25  |         let body
  26  |         try { body = await response.json() } catch { body = null }
  27  |         http.push({ method: request.method(), path: new URL(response.url()).pathname, status: response.status(), request: request.postDataJSON(), body })
  28  |       }
  29  |     })
  30  |     const fixture = database('seed')
  31  |     const saveEvidence = (name, data) => fs.writeFileSync(path.join(evidence, `${width}-${name}.json`), JSON.stringify(data, null, 2))
  32  |     saveEvidence('fixture', fixture)
  33  |     await page.setViewportSize({ width, height: width === 390 ? 844 : 1000 })
  34  |     async function api(method, purchase, suffix = '', data, status = 200) {
  35  |       const url = `/api/purchase-orders/${purchase.id}/cost-allocation${suffix}/`
  36  |       const response = await page.request[method](url, data === undefined ? {} : { data })
  37  |       const body = await response.json()
  38  |       http.push({ method: method.toUpperCase(), path: url, status: response.status(), request: data, body })
  39  |       expect(response.status(), JSON.stringify(body)).toBe(status)
  40  |       return body
  41  |     }
  42  |     async function open(purchase) {
  43  |       await page.goto('/purchase-orders')
  44  |       const row = page.locator('.purchase-list-row').filter({ hasText: purchase.no })
  45  |       await row.getByRole('button', { name: /查看采购单/ }).click()
  46  |       const detail = page.getByRole('dialog', { name: '采购工作台' })
  47  |       await detail.getByRole('button', { name: '分配采购成本 / 公共费用' }).click()
  48  |       const modal = page.getByRole('dialog', { name: /采购成本分配/ })
  49  |       await expect(modal.getByRole('button', { name: '保存成本分配', exact: true })).toBeVisible()
  50  |       return modal
  51  |     }
  52  |     const legacy = fixture.purchases.legacy
  53  |     const before = database('snapshot')
  54  |     let modal = await open(legacy)
  55  |     await expect(modal).toContainText('按数量比例（历史记录）')
  56  |     await expect(modal.locator('.cost-result')).toContainText('500.00')
  57  |     await expect(modal.getByRole('button', { name: '保存成本分配', exact: true })).toBeDisabled()
  58  |     await page.screenshot({ path: path.join(evidence, `${width}-01-legacy-readonly.png`) })
  59  |     await modal.getByRole('button', { name: '改按金额分摊并预览' }).click()
  60  |     await page.getByTestId('dialog-cancel').click()
  61  |     expect(database('snapshot')).toEqual(before)
  62  |     await expect(modal).toContainText('按数量比例（历史记录）')
  63  |     await modal.getByRole('button', { name: '改按金额分摊并预览' }).click()
  64  |     await page.getByTestId('dialog-confirm').click()
  65  |     await expect(modal.locator('.cost-result')).toContainText('909.09')
  66  |     await expect(modal.locator('.cost-result')).toContainText('90.91')
  67  |     expect(database('snapshot')).toEqual(before)
  68  |     await page.screenshot({ path: path.join(evidence, `${width}-02-amount-preview.png`) })
  69  |     await modal.locator('.cost-result').scrollIntoViewIfNeeded()
  70  |     await page.screenshot({ path: path.join(evidence, `${width}-05-amount-result.png`) })
  71  |     await modal.getByRole('button', { name: '取消', exact: true }).click()
  72  |     await page.getByTestId('dialog-confirm').click()
  73  |     expect(database('snapshot')).toEqual(before)
  74  |     modal = await open(legacy)
  75  |     await expect(modal).toContainText('按数量比例（历史记录）')
  76  |     await modal.getByRole('button', { name: '改按金额分摊并预览' }).click()
  77  |     await page.getByTestId('dialog-confirm').click()
  78  |     await expect(modal.locator('.cost-result')).toContainText('909.09')
  79  |     const saved = page.waitForResponse(r => r.url().endsWith(`/purchase-orders/${legacy.id}/cost-allocation/`) && r.request().method() === 'POST')
  80  |     await modal.getByRole('button', { name: '保存成本分配', exact: true }).click()
  81  |     expect((await saved).status()).toBe(200)
  82  |     await expect(modal).not.toContainText('历史记录按数量分摊')
  83  |     await page.screenshot({ path: path.join(evidence, `${width}-03-amount-saved.png`) })
  84  |     await page.reload()
  85  |     modal = await open(legacy)
  86  |     await expect(modal.locator('.cost-result')).toContainText('909.09')
  87  |     await expect(modal).not.toContainText('按数量比例（历史记录）')
  88  |     const summary = await api('get', legacy)
  89  |     const payload = { version: summary.version, allocations: summary.allocations.map(a => ({ purchase_item: a.purchase_item, target_type: a.target_type, order: a.order, quantity: a.quantity })), expenses: [{ name: '非法数量法', amount: '1000', method: 'quantity' }] }
  90  |     const committed = database('snapshot')
  91  |     await api('post', legacy, '', payload, 400)
  92  |     await api('post', legacy, '-preview', payload, 400)
  93  |     expect(database('snapshot')).toEqual(committed)
  94  |     const zero = fixture.purchases.zero
  95  |     await api('post', zero, '', { version: 0, allocations: [], expenses: [{ name: '正费用', amount: '1000', method: 'amount' }] }, 400)
  96  |     expect(database('snapshot')).toEqual(committed)
  97  |     await api('post', zero, '', { version: 0, allocations: [], expenses: [] })
  98  |     const fresh = fixture.purchases.new
  99  |     modal = await open(fresh)
  100 |     for (const [index, order] of fixture.orders.entries()) {
  101 |       const item = modal.locator('.cost-item').nth(index)
> 102 |       await item.getByLabel('成本归属', { exact: true }).selectOption('order')
      |                                                      ^ Error: locator.selectOption: Test timeout of 120000ms exceeded.
  103 |       await item.getByLabel('销售订单', { exact: true }).selectOption(String(order))
  104 |     }
  105 |     await modal.getByRole('button', { name: '添加附加费用' }).click()
  106 |     await modal.getByLabel('金额（CNY）', { exact: true }).fill('1000')
  107 |     await expect(modal.locator('.cost-result')).toContainText('909.09')
  108 |     await expect(modal.locator('option[value="quantity"]')).toHaveCount(0)
  109 |     const freshSaved = page.waitForResponse(r => r.url().endsWith(`/purchase-orders/${fresh.id}/cost-allocation/`) && r.request().method() === 'POST')
  110 |     await modal.getByRole('button', { name: '保存成本分配', exact: true }).click()
  111 |     expect((await freshSaved).status()).toBe(200)
  112 |     await expect(modal.locator('.pending-badge')).toHaveCount(0)
  113 |     await modal.locator('.cost-result').scrollIntoViewIfNeeded()
  114 |     await page.screenshot({ path: path.join(evidence, `${width}-04-new-amount.png`) })
  115 |     const final = database('snapshot')
  116 |     const allowed = new Set(['crm.PurchaseOrder', 'crm.PurchaseCostAllocation', 'crm.OperationLog', 'crm.InventoryReservation'])
  117 |     expect(Object.fromEntries(Object.entries(final).filter(([key]) => !allowed.has(key)))).toEqual(Object.fromEntries(Object.entries(before).filter(([key]) => !allowed.has(key))))
  118 |     const savedNew = await api('get', fresh)
  119 |     expect(savedNew.allocations.map(row => Number(row.additional_amount))).toEqual([909.09, 90.91])
  120 |     expect(savedNew.allocations.map(row => row.order)).toEqual(fixture.orders)
  121 |     saveEvidence('database-final', final)
  122 |     saveEvidence('http', http)
  123 |   })
  124 | }
  125 | 
```