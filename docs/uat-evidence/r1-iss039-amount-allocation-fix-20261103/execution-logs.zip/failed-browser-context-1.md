# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: iss039-amount-allocation-real.spec.js >> amount-only and deliberate legacy conversion, real Chrome 390px
- Location: browser-tests\iss039-amount-allocation-real.spec.js:19:3

# Error details

```
Test timeout of 120000ms exceeded.
```

```
Error: locator.selectOption: Test timeout of 120000ms exceeded.
Call log:
  - waiting for getByRole('dialog', { name: /采购成本分配/ }).locator('.cost-item').first().getByLabel('成本归属', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=f4e3]:
  - complementary [ref=f4e4]:
    - generic [ref=f4e5]:
      - generic [ref=f4e6]: S
      - generic [ref=f4e7]:
        - strong [ref=f4e8]: 森爵照明管理系统
        - text: 客户 · 销售 · 产品
    - navigation [ref=f4e9]:
      - generic [ref=f4e10]: 经营
      - link "经营概览" [ref=f4e11] [cursor=pointer]:
        - /url: /
      - link "报表中心" [ref=f4e18] [cursor=pointer]:
        - /url: /reports
      - link "历史订单分析" [ref=f4e25] [cursor=pointer]:
        - /url: /historical-orders
      - generic [ref=f4e31]: 客户
      - link "客户管理" [ref=f4e32] [cursor=pointer]:
        - /url: /customers
      - link "联系人" [ref=f4e39] [cursor=pointer]:
        - /url: /contacts
      - link "跟进记录" [ref=f4e45] [cursor=pointer]:
        - /url: /follow-ups
      - generic [ref=f4e49]: 销售
      - link "报价管理" [ref=f4e50] [cursor=pointer]:
        - /url: /quotes
      - link "订单管理" [ref=f4e55] [cursor=pointer]:
        - /url: /orders
      - generic [ref=f4e61]: 采购与库存
      - link "供应商管理" [ref=f4e62] [cursor=pointer]:
        - /url: /suppliers
      - link "采购管理" [ref=f4e69] [cursor=pointer]:
        - /url: /purchase-orders
      - link "库存" [ref=f4e75] [cursor=pointer]:
        - /url: /inventory
      - link "库存流水" [ref=f4e80] [cursor=pointer]:
        - /url: /inventory-movements
      - generic [ref=f4e85]: 产品资料
      - link "产品管理" [ref=f4e86] [cursor=pointer]:
        - /url: /products
      - link "SKU 管理" [ref=f4e92] [cursor=pointer]:
        - /url: /skus
      - link "产品分类" [ref=f4e104] [cursor=pointer]:
        - /url: /categories
      - link "产品参数" [ref=f4e110] [cursor=pointer]:
        - /url: /product-parameters
      - link "包装管理" [ref=f4e113] [cursor=pointer]:
        - /url: /sku-packaging
      - link "交易单位" [ref=f4e119] [cursor=pointer]:
        - /url: /sku-trade-units
      - link "产品证书" [ref=f4e131] [cursor=pointer]:
        - /url: /product-certificates
      - link "HS 编码维护" [ref=f4e136] [cursor=pointer]:
        - /url: /hs-codes
      - generic [ref=f4e139]: 财务与工具
      - link "财务概览" [ref=f4e140] [cursor=pointer]:
        - /url: /finance
      - link "应收计划" [ref=f4e146] [cursor=pointer]:
        - /url: /receivables
      - link "应付计划" [ref=f4e152] [cursor=pointer]:
        - /url: /payables
      - link "财务流水" [ref=f4e158] [cursor=pointer]:
        - /url: /transactions
      - link "人民币资金" [ref=f4e164] [cursor=pointer]:
        - /url: /rmb-cash-events
      - link "数据导入" [ref=f4e170] [cursor=pointer]:
        - /url: /import
      - generic [ref=f4e175]: 组织与系统
      - link "组织与权限" [ref=f4e176] [cursor=pointer]:
        - /url: /organization
    - generic [ref=f4e181]:
      - generic [ref=f4e182]: J
      - generic [ref=f4e184]:
        - strong [ref=f4e185]: 开发身份：Johnson
        - generic [ref=f4e186]: 超级管理员 · 全部功能与数据权限
  - main [ref=f4e187]:
    - generic [ref=f4e188]:
      - button [ref=f4e189] [cursor=pointer]
      - generic [ref=f4e191]:
        - text: Procurement desk
        - heading "采购管理" [level=1] [ref=f4e192]
      - generic "Johnson" [ref=f4e194]: J
    - generic [ref=f4e196]:
      - dialog [ref=f4e198]:
        - generic [ref=f4e199]:
          - generic [ref=f4e200]:
            - text: 采购管理 / 成本核算
            - heading "采购成本分配 C039-00c327a7-new" [level=3] [ref=f4e201]:
              - text: 采购成本分配
              - generic [ref=f4e202]: C039-00c327a7-new
            - paragraph [ref=f4e203]: 将商品成本分配给订单与库存，再统一分摊公共费用。
          - button "关闭成本分配" [ref=f4e204] [cursor=pointer]
        - generic [ref=f4e208]:
          - article [ref=f4e209]:
            - generic [ref=f4e210]: 采购商品金额
            - strong [ref=f4e211]: 11,000.00 CNY
          - article [ref=f4e212]:
            - generic [ref=f4e213]: 公共附加费用
            - strong [ref=f4e214]: 0.00 CNY
          - article [ref=f4e215]:
            - generic [ref=f4e216]: 本次核算总成本
            - strong [ref=f4e217]: 11,000.00 CNY
        - group [ref=f4e219]:
          - paragraph [ref=f4e220]: 采购成本默认归来源订单，无来源订单时归库存。保存调整后保留分配版本。
          - generic [ref=f4e223]:
            - generic [ref=f4e224]:
              - heading "明细成本归属" [level=4] [ref=f4e225]
              - paragraph [ref=f4e230]: 展开商品，填写每份归属的数量；未分配的余量自动归库存。
            - generic [ref=f4e231]: 2 项商品
          - group [ref=f4e232]:
            - generic "› C039-00c327a7 合成商品 C039-00c327a7 · 采购 10.00 件 × CNY 1,000.00 · 分配基数 10.00 件 剩余 0.00" [ref=f4e233] [cursor=pointer]:
              - text: ›
              - generic [ref=f4e234]:
                - generic [ref=f4e235]: C039-00c327a7 合成商品
                - generic [ref=f4e236]: C039-00c327a7 · 采购 10.00 件 × CNY 1,000.00 · 分配基数 10.00 件
              - generic [ref=f4e237]: 剩余 0.00
            - generic [ref=f4e238]:
              - generic [ref=f4e239]:
                - text: 成本归属
                - combobox "成本归属" [ref=f4e240]:
                  - option "销售订单"
                  - option "库存" [selected]
                  - option "样品"
                  - option "损耗"
                  - option "赠品"
                  - option "售后补发"
                  - option "研发试制"
                  - option "内部领用"
                  - option "展会推广"
                  - option "其他"
              - generic [ref=f4e241]:
                - text: 分配数量
                - spinbutton "分配数量" [ref=f4e242]: "10"
              - button "删除" [ref=f4e243] [cursor=pointer]
            - button "添加成本归属" [ref=f4e244] [cursor=pointer]
          - group [ref=f4e246]:
            - generic "› C039-00c327a7 合成商品 C039-00c327a7 · 采购 10.00 件 × CNY 100.00 · 分配基数 10.00 件 剩余 0.00" [ref=f4e247] [cursor=pointer]:
              - text: ›
              - generic [ref=f4e248]:
                - generic [ref=f4e249]: C039-00c327a7 合成商品
                - generic [ref=f4e250]: C039-00c327a7 · 采购 10.00 件 × CNY 100.00 · 分配基数 10.00 件
              - generic [ref=f4e251]: 剩余 0.00
            - generic [ref=f4e252]:
              - generic [ref=f4e253]:
                - text: 成本归属
                - combobox "成本归属" [ref=f4e254]:
                  - option "销售订单"
                  - option "库存" [selected]
                  - option "样品"
                  - option "损耗"
                  - option "赠品"
                  - option "售后补发"
                  - option "研发试制"
                  - option "内部领用"
                  - option "展会推广"
                  - option "其他"
              - generic [ref=f4e255]:
                - text: 分配数量
                - spinbutton "分配数量" [ref=f4e256]: "10"
              - button "删除" [ref=f4e257] [cursor=pointer]
            - button "添加成本归属" [ref=f4e258] [cursor=pointer]
          - generic [ref=f4e261]:
            - heading "公共附加费用" [level=4] [ref=f4e262]
            - paragraph [ref=f4e268]: 运费、关税等公共费用按采购金额比例分摊。
          - generic [ref=f4e269]: 暂无附加费用，可添加运费、关税或杂费。
          - paragraph [ref=f4e270]: 公共费用按采购金额比例分担，历史记录保留原算法。此处不生成付款或入库；已分摊的费用请勿再次作为订单费用录入。
          - button "添加附加费用" [ref=f4e271] [cursor=pointer]
        - generic [ref=f4e273]:
          - heading "当前成本归属" [level=4] [ref=f4e274]
          - table [ref=f4e276]:
            - rowgroup [ref=f4e277]:
              - row [ref=f4e278]:
                - columnheader "采购明细" [ref=f4e279]
                - columnheader "归属" [ref=f4e280]
                - columnheader "数量" [ref=f4e281]
                - columnheader "商品成本" [ref=f4e282]
                - columnheader "附加费用" [ref=f4e283]
                - columnheader "合计" [ref=f4e284]
            - rowgroup [ref=f4e285]:
              - row [ref=f4e286]:
                - cell "C039-00c327a7 合成商品" [ref=f4e287]
                - cell "库存" [ref=f4e288]
                - cell "10" [ref=f4e289]
                - cell "10,000.00" [ref=f4e290]
                - cell "0.00" [ref=f4e291]
                - cell "10,000.00" [ref=f4e292]
              - row [ref=f4e293]:
                - cell "C039-00c327a7 合成商品" [ref=f4e294]
                - cell "库存" [ref=f4e295]
                - cell "10" [ref=f4e296]
                - cell "1,000.00" [ref=f4e297]
                - cell "0.00" [ref=f4e298]
                - cell "1,000.00" [ref=f4e299]
          - paragraph [ref=f4e300]: 商品成本 11,000.00 ＋ 附加费用 0.00 ＝ CNY 11,000.00
          - paragraph [ref=f4e301]: 草稿及取消采购不计入订单预估毛利；库存成本表示成本归属，不代表已到货库存。
        - generic [ref=f4e302]:
          - generic [ref=f4e303]: 修改数量、归属或费用，自动更新预览
          - generic [ref=f4e304]:
            - button "取消" [ref=f4e305] [cursor=pointer]
            - button "保存成本分配" [ref=f4e306] [cursor=pointer]
      - generic [ref=f4e309]:
        - paragraph [ref=f4e310]: 管理采购下单、到货与供应商应付。
        - generic [ref=f4e311]:
          - button "刷新" [ref=f4e312] [cursor=pointer]
          - button "新建采购单" [ref=f4e318] [cursor=pointer]
      - region "页面小计" [ref=f4e321]:
        - article [ref=f4e322]:
          - generic [ref=f4e323]: 执行中
          - strong [ref=f4e324]: "6"
          - generic [ref=f4e325]: 已下单 / 部分到货
        - article [ref=f4e329]:
          - generic [ref=f4e330]: 待到货
          - strong [ref=f4e331]: "6"
          - generic [ref=f4e332]: 尚未全部到货
        - article [ref=f4e336]:
          - generic [ref=f4e337]: 待付款
          - strong [ref=f4e338]: "4"
          - generic [ref=f4e339]: 仍有应付余额
        - article [ref=f4e343]:
          - generic [ref=f4e344]: 已完成
          - strong [ref=f4e345]: "0"
          - generic [ref=f4e346]: 已完成采购
      - generic "采购单筛选" [ref=f4e350]:
        - generic [ref=f4e351]:
          - generic [ref=f4e352]: 搜索
          - searchbox "搜索采购单号、供应商、来源订单" [ref=f4e353]
        - generic [ref=f4e354]:
          - generic [ref=f4e355]: 状态
          - combobox "按状态筛选" [ref=f4e356]:
            - option "全部状态" [selected]
            - option "草稿"
            - option "已下单"
            - option "部分到货"
            - option "已完成"
            - option "已取消"
        - generic [ref=f4e357]:
          - checkbox "仅看待到货" [ref=f4e358]
          - text: 仅看待到货
        - button "重置" [disabled] [ref=f4e359] [cursor=pointer]
      - table [ref=f4e362]:
        - rowgroup [ref=f4e363]:
          - row [ref=f4e364]:
            - columnheader "采购单号" [ref=f4e365]
            - columnheader "供应商" [ref=f4e366]
            - columnheader "来源订单" [ref=f4e367]
            - columnheader "下单日期" [ref=f4e368]
            - columnheader "预计到货" [ref=f4e369]
            - columnheader "状态" [ref=f4e370]
            - columnheader "采购金额" [ref=f4e371]
            - columnheader "已付 / 未付" [ref=f4e372]
            - columnheader "操作" [ref=f4e373]
        - rowgroup [ref=f4e374]:
          - row [ref=f4e375] [cursor=pointer]:
            - cell "C039-00c327a7-zero" [ref=f4e376]
            - cell "历史主体未记录" [ref=f4e377]
            - cell "—" [ref=f4e378]
            - cell "2026-11-03" [ref=f4e379]
            - cell "—" [ref=f4e380]
            - cell "已下单" [ref=f4e382]
            - cell "CNY 0.00" [ref=f4e384]
            - cell "0.00 / 0.00" [ref=f4e385]
            - cell [ref=f4e386]:
              - button "查看采购单 C039-00c327a7-zero" [ref=f4e387]
          - row [ref=f4e391] [cursor=pointer]:
            - cell "C039-00c327a7-legacy" [ref=f4e392]
            - cell "历史主体未记录" [ref=f4e393]
            - cell "—" [ref=f4e394]
            - cell "2026-11-03" [ref=f4e395]
            - cell "—" [ref=f4e396]
            - cell "已下单" [ref=f4e398]
            - cell "CNY 11,000.00" [ref=f4e400]
            - cell "0.00 / 11,000.00" [ref=f4e401]
            - cell [ref=f4e402]:
              - button "查看采购单 C039-00c327a7-legacy" [ref=f4e403]
          - row [ref=f4e407] [cursor=pointer]:
            - cell "C039-00c327a7-new" [ref=f4e408]
            - cell "历史主体未记录" [ref=f4e409]
            - cell "—" [ref=f4e410]
            - cell "2026-11-03" [ref=f4e411]
            - cell "—" [ref=f4e412]
            - cell "已下单" [ref=f4e414]
            - cell "CNY 11,000.00" [ref=f4e416]
            - cell "0.00 / 11,000.00" [ref=f4e417]
            - cell [ref=f4e418]:
              - button "查看采购单 C039-00c327a7-new" [ref=f4e419]
          - row [ref=f4e423] [cursor=pointer]:
            - cell "C039-62a30bb3-zero" [ref=f4e424]
            - cell "历史主体未记录" [ref=f4e425]
            - cell "—" [ref=f4e426]
            - cell "2026-11-03" [ref=f4e427]
            - cell "—" [ref=f4e428]
            - cell "已下单" [ref=f4e430]
            - cell "CNY 0.00" [ref=f4e432]
            - cell "0.00 / 0.00" [ref=f4e433]
            - cell [ref=f4e434]:
              - button "查看采购单 C039-62a30bb3-zero" [ref=f4e435]
          - row [ref=f4e439] [cursor=pointer]:
            - cell "C039-62a30bb3-legacy" [ref=f4e440]
            - cell "历史主体未记录" [ref=f4e441]
            - cell "—" [ref=f4e442]
            - cell "2026-11-03" [ref=f4e443]
            - cell "—" [ref=f4e444]
            - cell "已下单" [ref=f4e446]
            - cell "CNY 11,000.00" [ref=f4e448]
            - cell "0.00 / 11,000.00" [ref=f4e449]
            - cell [ref=f4e450]:
              - button "查看采购单 C039-62a30bb3-legacy" [ref=f4e451]
          - row [ref=f4e455] [cursor=pointer]:
            - cell "C039-62a30bb3-new" [ref=f4e456]
            - cell "历史主体未记录" [ref=f4e457]
            - cell "—" [ref=f4e458]
            - cell "2026-11-03" [ref=f4e459]
            - cell "—" [ref=f4e460]
            - cell "已下单" [ref=f4e462]
            - cell "CNY 11,000.00" [ref=f4e464]
            - cell "0.00 / 11,000.00" [ref=f4e465]
            - cell [ref=f4e466]:
              - button "查看采购单 C039-62a30bb3-new" [ref=f4e467]
      - dialog "采购工作台" [ref=f4e472]:
        - generic [ref=f4e473]:
          - button "关闭采购详情" [ref=f4e474] [cursor=pointer]:
            - generic [ref=f4e478]: 关闭
          - generic [ref=f4e479]: 采购工作台
          - paragraph [ref=f4e480]: 历史主体未记录 · 下单日期 2026-11-03
          - heading "C039-00c327a7-new 已下单" [level=2] [ref=f4e481]:
            - text: C039-00c327a7-new
            - generic [ref=f4e482]: 已下单
          - paragraph [ref=f4e483]: 预计到货 —
          - button "取消采购单" [ref=f4e485] [cursor=pointer]
        - navigation "采购工作台页签" [ref=f4e486]:
          - button "概览" [pressed] [ref=f4e487] [cursor=pointer]
          - button "采购明细" [ref=f4e488] [cursor=pointer]
          - button "收货" [ref=f4e489] [cursor=pointer]
          - button "供应商应付" [ref=f4e490] [cursor=pointer]
          - button "关联销售订单" [ref=f4e491] [cursor=pointer]
        - main [ref=f4e492]:
          - article [ref=f4e493]:
            - heading "交易主体快照" [level=3] [ref=f4e494]
            - paragraph [ref=f4e495]: 历史主体未记录，以下不使用当前主档补造历史事实。
            - paragraph [ref=f4e496]: 当前主档参考：C039-00c327a7 合成供应商
          - article [ref=f4e497]:
            - heading "采购摘要" [level=3] [ref=f4e498]
            - generic [ref=f4e499]:
              - generic [ref=f4e500]:
                - generic [ref=f4e501]: 采购金额
                - strong [ref=f4e502]: CNY 11,000.00
              - generic [ref=f4e503]:
                - generic [ref=f4e504]: 商品项数
                - strong [ref=f4e505]: "2"
              - generic [ref=f4e506]:
                - generic [ref=f4e507]: 已付金额
                - strong [ref=f4e508]: CNY 0.00
              - generic [ref=f4e509]:
                - generic [ref=f4e510]: 未付金额
                - strong [ref=f4e511]: CNY 11,000.00
          - article [ref=f4e512]:
            - heading "当前待办" [level=3] [ref=f4e513]
            - generic [ref=f4e514]:
              - generic [ref=f4e515]:
                - text: 待到货
                - paragraph [ref=f4e516]: 还有 2 条明细未全部到货。
              - button "查看收货" [ref=f4e517] [cursor=pointer]
            - generic [ref=f4e518]:
              - generic [ref=f4e519]:
                - text: 待付款
                - paragraph [ref=f4e520]: 待付 CNY 11000.00
              - button "查看 / 登记付款" [ref=f4e521] [cursor=pointer]
          - generic [ref=f4e522]:
            - article [ref=f4e523]:
              - heading "到货进度" [level=3] [ref=f4e524]
              - generic [ref=f4e525]:
                - term [ref=f4e526]: 采购数量
                - definition [ref=f4e527]: 20 件
                - term [ref=f4e528]: 已到货
                - definition [ref=f4e529]: "0"
                - term [ref=f4e530]: 待到货
                - definition [ref=f4e531]: "20"
                - term [ref=f4e532]: 完成比例
                - definition [ref=f4e533]: 0%
            - article [ref=f4e534]:
              - heading "付款进度" [level=3] [ref=f4e535]
              - generic [ref=f4e536]:
                - term [ref=f4e537]: 应付 / 合同金额
                - definition [ref=f4e538]: CNY 11,000.00
                - term [ref=f4e539]: 已付
                - definition [ref=f4e540]: "0.00"
                - term [ref=f4e541]: 未付
                - definition [ref=f4e542]: 11,000.00
                - term [ref=f4e543]: 付款百分比
                - definition [ref=f4e544]: 0%
              - button "登记付款" [ref=f4e545] [cursor=pointer]
            - article [ref=f4e546]:
              - heading "采购成本分配" [level=3] [ref=f4e547]
              - paragraph [ref=f4e548]: 将采购成本和公共费用分配到关联销售订单。
              - button "分配采购成本 / 公共费用" [active] [ref=f4e549] [cursor=pointer]
          - generic [ref=f4e550]:
            - generic [ref=f4e551]:
              - generic [ref=f4e552]:
                - heading "合同金额调整" [level=4] [ref=f4e553]
                - paragraph [ref=f4e554]: 已确认调整会改变当前合同总额；调减只会减少未结清计划，不会自动退款。
              - strong [ref=f4e555]: CNY 11,000.00
            - generic [ref=f4e556]:
              - generic [ref=f4e557]: 基础金额 CNY 11,000.00
              - generic [ref=f4e558]: 已确认调整 CNY 0.00
            - generic [ref=f4e559]:
              - spinbutton "调整金额（正/负）" [ref=f4e560]
              - textbox [ref=f4e561]
              - textbox "调整说明" [ref=f4e562]
              - button "新增调整" [ref=f4e563] [cursor=pointer]
            - paragraph [ref=f4e564]: 暂无金额调整记录。
```

# Test source

```ts
  2   | import { spawnSync } from 'node:child_process'
  3   | import fs from 'node:fs'
  4   | import path from 'node:path'
  5   | 
  6   | test.use({ channel: 'chrome' })
  7   | const evidence = path.resolve(process.env.ISS039_EVIDENCE_ROOT || (process.env.ISOLATED_PLAYWRIGHT_EVIDENCE_ROOT ? path.join(process.env.ISOLATED_PLAYWRIGHT_EVIDENCE_ROOT, 'browser', 'iss039-amount-allocation') : '../docs/uat-evidence/r1-iss039-amount-allocation-fix-20261103/browser'))
  8   | const inspector = path.resolve('../docs/uat-evidence/r1-iss039-amount-allocation-fix-20261103/fixture.py')
  9   | fs.mkdirSync(evidence, { recursive: true })
  10  | 
  11  | function database(action) {
  12  |   if (!process.env.ISOLATED_TEST_PYTHON || !process.env.ISOLATED_TEST_RUN_ID) throw new Error('Use the verified isolated browser runner.')
  13  |   const result = spawnSync(process.env.ISOLATED_TEST_PYTHON, [inspector, action], { cwd: path.resolve('../backend'), env: process.env, encoding: 'utf8' })
  14  |   expect(result.status, result.stderr).toBe(0)
  15  |   return JSON.parse(result.stdout)
  16  | }
  17  | 
  18  | const fixtures = new Map()
  19  | test.beforeAll(() => {
  20  |   for (const width of [1440, 390]) fixtures.set(width, database('seed'))
  21  | })
  22  | 
  23  | for (const width of [1440, 390]) {
  24  |   test(`amount-only and deliberate legacy conversion, real Chrome ${width}px`, async ({ page }) => {
  25  |     test.setTimeout(120000)
  26  |     const http = []
  27  |     page.on('response', async response => {
  28  |       const request = response.request()
  29  |       if (response.url().includes('/cost-allocation')) {
  30  |         let body
  31  |         try { body = await response.json() } catch { body = null }
  32  |         http.push({ method: request.method(), path: new URL(response.url()).pathname, status: response.status(), request: request.postDataJSON(), body })
  33  |       }
  34  |     })
  35  |     const fixture = fixtures.get(width)
  36  |     const saveEvidence = (name, data) => fs.writeFileSync(path.join(evidence, `${width}-${name}.json`), JSON.stringify(data, null, 2))
  37  |     saveEvidence('fixture', fixture)
  38  |     await page.setViewportSize({ width, height: width === 390 ? 844 : 1000 })
  39  |     async function api(method, purchase, suffix = '', data, status = 200) {
  40  |       const url = `/api/purchase-orders/${purchase.id}/cost-allocation${suffix}/`
  41  |       const response = await page.request[method](url, data === undefined ? {} : { data })
  42  |       const body = await response.json()
  43  |       http.push({ method: method.toUpperCase(), path: url, status: response.status(), request: data, body })
  44  |       expect(response.status(), JSON.stringify(body)).toBe(status)
  45  |       return body
  46  |     }
  47  |     async function open(purchase) {
  48  |       await page.goto('/purchase-orders')
  49  |       const row = page.locator('.purchase-list-row').filter({ hasText: purchase.no })
  50  |       await row.getByRole('button', { name: /查看采购单/ }).click()
  51  |       const detail = page.getByRole('dialog', { name: '采购工作台' })
  52  |       await detail.getByRole('button', { name: '分配采购成本 / 公共费用' }).click()
  53  |       const modal = page.getByRole('dialog', { name: /采购成本分配/ })
  54  |       await expect(modal.getByRole('button', { name: '保存成本分配', exact: true })).toBeVisible()
  55  |       return modal
  56  |     }
  57  |     const legacy = fixture.purchases.legacy
  58  |     const before = database('snapshot')
  59  |     let modal = await open(legacy)
  60  |     await expect(modal).toContainText('按数量比例（历史记录）')
  61  |     await expect(modal.locator('.cost-result')).toContainText('500.00')
  62  |     await expect(modal.getByRole('button', { name: '保存成本分配', exact: true })).toBeDisabled()
  63  |     await page.screenshot({ path: path.join(evidence, `${width}-01-legacy-readonly.png`) })
  64  |     await modal.getByRole('button', { name: '改按金额分摊并预览' }).click()
  65  |     await page.getByTestId('dialog-cancel').click()
  66  |     expect(database('snapshot')).toEqual(before)
  67  |     await expect(modal).toContainText('按数量比例（历史记录）')
  68  |     await modal.getByRole('button', { name: '改按金额分摊并预览' }).click()
  69  |     await page.getByTestId('dialog-confirm').click()
  70  |     await expect(modal.locator('.cost-result')).toContainText('909.09')
  71  |     await expect(modal.locator('.cost-result')).toContainText('90.91')
  72  |     expect(database('snapshot')).toEqual(before)
  73  |     await page.screenshot({ path: path.join(evidence, `${width}-02-amount-preview.png`) })
  74  |     await modal.locator('.cost-result').scrollIntoViewIfNeeded()
  75  |     await page.screenshot({ path: path.join(evidence, `${width}-05-amount-result.png`) })
  76  |     await modal.getByRole('button', { name: '取消', exact: true }).click()
  77  |     await page.getByTestId('dialog-confirm').click()
  78  |     expect(database('snapshot')).toEqual(before)
  79  |     modal = await open(legacy)
  80  |     await expect(modal).toContainText('按数量比例（历史记录）')
  81  |     await modal.getByRole('button', { name: '改按金额分摊并预览' }).click()
  82  |     await page.getByTestId('dialog-confirm').click()
  83  |     await expect(modal.locator('.cost-result')).toContainText('909.09')
  84  |     const saved = page.waitForResponse(r => r.url().endsWith(`/purchase-orders/${legacy.id}/cost-allocation/`) && r.request().method() === 'POST')
  85  |     await modal.getByRole('button', { name: '保存成本分配', exact: true }).click()
  86  |     expect((await saved).status()).toBe(200)
  87  |     await expect(modal).not.toContainText('历史记录按数量分摊')
  88  |     await page.screenshot({ path: path.join(evidence, `${width}-03-amount-saved.png`) })
  89  |     await page.reload()
  90  |     modal = await open(legacy)
  91  |     await expect(modal.locator('.cost-result')).toContainText('909.09')
  92  |     await expect(modal).not.toContainText('按数量比例（历史记录）')
  93  |     const summary = await api('get', legacy)
  94  |     const payload = { version: summary.version, allocations: summary.allocations.map(a => ({ purchase_item: a.purchase_item, target_type: a.target_type, order: a.order, quantity: a.quantity })), expenses: [{ name: '非法数量法', amount: '1000', method: 'quantity' }] }
  95  |     const committed = database('snapshot')
  96  |     await api('post', legacy, '', payload, 400)
  97  |     await api('post', legacy, '-preview', payload, 400)
  98  |     expect(database('snapshot')).toEqual(committed)
  99  |     const zero = fixture.purchases.zero
  100 |     await api('post', zero, '', { version: 0, allocations: [], expenses: [{ name: '正费用', amount: '1000', method: 'amount' }] }, 400)
  101 |     expect(database('snapshot')).toEqual(committed)
> 102 |     await api('post', zero, '', { version: 0, allocations: [], expenses: [] })
      |                                                      ^ Error: locator.selectOption: Test timeout of 120000ms exceeded.
  103 |     const fresh = fixture.purchases.new
  104 |     modal = await open(fresh)
  105 |     for (const [index, order] of fixture.orders.entries()) {
  106 |       const item = modal.locator('.cost-item').nth(index)
  107 |       await item.locator('.cost-row select').first().selectOption('order')
  108 |       await item.locator('.cost-row select').nth(1).selectOption(String(order))
  109 |     }
  110 |     await modal.getByRole('button', { name: '添加附加费用' }).click()
  111 |     await modal.getByLabel('金额（CNY）', { exact: true }).fill('1000')
  112 |     await expect(modal.locator('.cost-result')).toContainText('909.09')
  113 |     await expect(modal.locator('option[value="quantity"]')).toHaveCount(0)
  114 |     const freshSaved = page.waitForResponse(r => r.url().endsWith(`/purchase-orders/${fresh.id}/cost-allocation/`) && r.request().method() === 'POST')
  115 |     await modal.getByRole('button', { name: '保存成本分配', exact: true }).click()
  116 |     expect((await freshSaved).status()).toBe(200)
  117 |     await expect(modal.locator('.pending-badge')).toHaveCount(0)
  118 |     await modal.locator('.cost-result').scrollIntoViewIfNeeded()
  119 |     await page.screenshot({ path: path.join(evidence, `${width}-04-new-amount.png`) })
  120 |     const final = database('snapshot')
  121 |     const allowed = new Set(['crm.PurchaseOrder', 'crm.PurchaseCostAllocation', 'crm.OperationLog', 'crm.InventoryReservation'])
  122 |     expect(Object.fromEntries(Object.entries(final).filter(([key]) => !allowed.has(key)))).toEqual(Object.fromEntries(Object.entries(before).filter(([key]) => !allowed.has(key))))
  123 |     const savedNew = await api('get', fresh)
  124 |     expect(savedNew.allocations.map(row => Number(row.additional_amount))).toEqual([909.09, 90.91])
  125 |     expect(savedNew.allocations.map(row => row.order)).toEqual(fixture.orders)
  126 |     saveEvidence('database-final', final)
  127 |     saveEvidence('http', http)
  128 |   })
  129 | }
  130 | 
```