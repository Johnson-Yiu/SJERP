# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: iss039-amount-allocation-real.spec.js >> amount-only and deliberate legacy conversion, real Chrome 1440px
- Location: browser-tests/iss039-amount-allocation-real.spec.js:24:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: null
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test'
  2   | import { spawnSync } from 'node:child_process'
  3   | import fs from 'node:fs'
  4   | import path from 'node:path'
  5   | 
  6   | test.use({ channel: 'chrome' })
  7   | const evidence = path.resolve(process.env.ISS039_EVIDENCE_ROOT || (process.env.ISOLATED_PLAYWRIGHT_EVIDENCE_ROOT ? path.join(process.env.ISOLATED_PLAYWRIGHT_EVIDENCE_ROOT, 'browser', 'iss039-amount-allocation') : '../docs/uat-evidence/r1-iss039-amount-allocation-fix-20261103/browser'))
  8   | const inspector = path.resolve('../docs/uat-evidence/r1-iss039-amount-allocation-fix-20261103/fixture.py')
  9   | fs.mkdirSync(evidence, { recursive: true })
  10  | 
  11  | function database(action) {
  12  |   if (!process.env.ISOLATED_TEST_PYTHON || !process.env.ISOLATED_TEST_RUN_ID) throw new Error('Use the verified isolated browser runner.')
  13  |   const result = spawnSync(process.env.ISOLATED_TEST_PYTHON, [inspector, action], { cwd: path.resolve('../backend'), env: process.env, encoding: 'utf8' })
> 14  |   expect(result.status, result.stderr).toBe(0)
      |                                        ^ Error: expect(received).toBe(expected) // Object.is equality
  15  |   return JSON.parse(result.stdout)
  16  | }
  17  | 
  18  | const fixtures = new Map()
  19  | test.beforeAll(() => {
  20  |   for (const width of [1440, 390]) fixtures.set(width, database('seed'))
  21  | })
  22  | 
  23  | for (const width of [1440, 390]) {
  24  |   test(`amount-only and deliberate legacy conversion, real Chrome ${width}px`, async ({ page }) => {
  25  |     test.setTimeout(120000)
  26  |     const http = []
  27  |     page.on('response', async response => {
  28  |       const request = response.request()
  29  |       if (response.url().includes('/cost-allocation')) {
  30  |         let body
  31  |         try { body = await response.json() } catch { body = null }
  32  |         http.push({ method: request.method(), path: new URL(response.url()).pathname, status: response.status(), request: request.postDataJSON(), body })
  33  |       }
  34  |     })
  35  |     const fixture = fixtures.get(width)
  36  |     const saveEvidence = (name, data) => fs.writeFileSync(path.join(evidence, `${width}-${name}.json`), JSON.stringify(data, null, 2))
  37  |     saveEvidence('fixture', fixture)
  38  |     await page.setViewportSize({ width, height: width === 390 ? 844 : 1000 })
  39  |     async function api(method, purchase, suffix = '', data, status = 200) {
  40  |       const url = `/api/purchase-orders/${purchase.id}/cost-allocation${suffix}/`
  41  |       const response = await page.request[method](url, data === undefined ? {} : { data })
  42  |       const body = await response.json()
  43  |       http.push({ method: method.toUpperCase(), path: url, status: response.status(), request: data, body })
  44  |       expect(response.status(), JSON.stringify(body)).toBe(status)
  45  |       return body
  46  |     }
  47  |     async function open(purchase) {
  48  |       await page.goto('/purchase-orders')
  49  |       const row = page.locator('.purchase-list-row').filter({ hasText: purchase.no })
  50  |       await row.getByRole('button', { name: /查看采购单/ }).click()
  51  |       const detail = page.getByRole('dialog', { name: '采购工作台' })
  52  |       await detail.getByRole('button', { name: '分配采购成本 / 公共费用' }).click()
  53  |       const modal = page.getByRole('dialog', { name: /采购成本分配/ })
  54  |       await expect(modal.getByRole('button', { name: '保存成本分配', exact: true })).toBeVisible()
  55  |       return modal
  56  |     }
  57  |     const legacy = fixture.purchases.legacy
  58  |     const before = database('snapshot')
  59  |     let modal = await open(legacy)
  60  |     await expect(modal).toContainText('按数量比例（历史记录）')
  61  |     await expect(modal.locator('.cost-result')).toContainText('500.00')
  62  |     await expect(modal.getByRole('button', { name: '保存成本分配', exact: true })).toBeDisabled()
  63  |     await page.screenshot({ path: path.join(evidence, `${width}-01-legacy-readonly.png`) })
  64  |     await modal.getByRole('button', { name: '改按金额分摊并预览' }).click()
  65  |     await page.getByTestId('dialog-cancel').click()
  66  |     expect(database('snapshot')).toEqual(before)
  67  |     await expect(modal).toContainText('按数量比例（历史记录）')
  68  |     await modal.getByRole('button', { name: '改按金额分摊并预览' }).click()
  69  |     await page.getByTestId('dialog-confirm').click()
  70  |     await expect(modal.locator('.cost-result')).toContainText('909.09')
  71  |     await expect(modal.locator('.cost-result')).toContainText('90.91')
  72  |     expect(database('snapshot')).toEqual(before)
  73  |     await page.screenshot({ path: path.join(evidence, `${width}-02-amount-preview.png`) })
  74  |     await modal.locator('.cost-result').scrollIntoViewIfNeeded()
  75  |     await page.screenshot({ path: path.join(evidence, `${width}-05-amount-result.png`) })
  76  |     await modal.getByRole('button', { name: '取消', exact: true }).click()
  77  |     await page.getByTestId('dialog-confirm').click()
  78  |     expect(database('snapshot')).toEqual(before)
  79  |     modal = await open(legacy)
  80  |     await expect(modal).toContainText('按数量比例（历史记录）')
  81  |     await modal.getByRole('button', { name: '改按金额分摊并预览' }).click()
  82  |     await page.getByTestId('dialog-confirm').click()
  83  |     await expect(modal.locator('.cost-result')).toContainText('909.09')
  84  |     const saved = page.waitForResponse(r => r.url().endsWith(`/purchase-orders/${legacy.id}/cost-allocation/`) && r.request().method() === 'POST')
  85  |     await modal.getByRole('button', { name: '保存成本分配', exact: true }).click()
  86  |     expect((await saved).status()).toBe(200)
  87  |     await expect(modal).not.toContainText('历史记录按数量分摊')
  88  |     await page.screenshot({ path: path.join(evidence, `${width}-03-amount-saved.png`) })
  89  |     await page.reload()
  90  |     modal = await open(legacy)
  91  |     await expect(modal.locator('.cost-result')).toContainText('909.09')
  92  |     await expect(modal).not.toContainText('按数量比例（历史记录）')
  93  |     const summary = await api('get', legacy)
  94  |     const payload = { version: summary.version, allocations: summary.allocations.map(a => ({ purchase_item: a.purchase_item, target_type: a.target_type, order: a.order, quantity: a.quantity })), expenses: [{ name: '非法数量法', amount: '1000', method: 'quantity' }] }
  95  |     const committed = database('snapshot')
  96  |     await api('post', legacy, '', payload, 400)
  97  |     await api('post', legacy, '-preview', payload, 400)
  98  |     expect(database('snapshot')).toEqual(committed)
  99  |     const zero = fixture.purchases.zero
  100 |     await api('post', zero, '', { version: 0, allocations: [], expenses: [{ name: '正费用', amount: '1000', method: 'amount' }] }, 400)
  101 |     expect(database('snapshot')).toEqual(committed)
  102 |     await api('post', zero, '', { version: 0, allocations: [], expenses: [] })
  103 |     const fresh = fixture.purchases.new
  104 |     modal = await open(fresh)
  105 |     for (const [index, order] of fixture.orders.entries()) {
  106 |       const item = modal.locator('.cost-item').nth(index)
  107 |       await item.locator('.cost-row select').first().selectOption('order')
  108 |       await item.locator('.cost-row select').nth(1).selectOption(String(order))
  109 |     }
  110 |     await modal.getByRole('button', { name: '添加附加费用' }).click()
  111 |     await modal.getByLabel('金额（CNY）', { exact: true }).fill('1000')
  112 |     await expect(modal.locator('.cost-result')).toContainText('909.09')
  113 |     await expect(modal.locator('option[value="quantity"]')).toHaveCount(0)
  114 |     const freshSaved = page.waitForResponse(r => r.url().endsWith(`/purchase-orders/${fresh.id}/cost-allocation/`) && r.request().method() === 'POST')
```